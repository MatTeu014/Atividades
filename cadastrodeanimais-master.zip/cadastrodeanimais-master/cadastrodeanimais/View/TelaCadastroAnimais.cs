﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using cadastrodeanimais.Controller;
using cadastrodeanimais.Model;

namespace cadastrodeanimais.View
{
    public partial class TelaCadastroAnimais : Form
    {
        public TelaCadastroAnimais()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dwad_Click(object sender, EventArgs e)
        {

        }

        private void btn_cadastrar_Click(object sender, EventArgs e)
        {
            Animais.Nome = tbx_name.Text;
            Animais.Raca = tbx_raca.Text;
            Animais.Porte = cbx_porte.Text;

            ControllerAnimais controlleranimais = new ControllerAnimais();
            controlleranimais.EnviarBanco();
        }
    }
}
