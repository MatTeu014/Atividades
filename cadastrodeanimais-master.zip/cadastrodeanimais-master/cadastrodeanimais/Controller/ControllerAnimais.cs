﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using cadastrodeanimais.Model;

namespace cadastrodeanimais.Controller
{
    internal class ControllerAnimais
    {
        //crud
        //c-create/inserir registros na tabela do banco.
        //r-read/ler os registros da tabela do banco.
        //u-update/alterar registros da tabela do banco.
        //d-delete/apagar registros da tabela do banco.

        //Método de inserir registros na tabela.
        public void EnviarBanco()
        {
            SqlConnection cn = new SqlConnection(Conexao.Conectar());
            SqlCommand cmd = new SqlCommand("PCadastroAnimais", cn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            try
            {

                cmd.Parameters.AddWithValue("@nome", Animais.Nome);
                cmd.Parameters.AddWithValue("@raca", Animais.Raca);
                cmd.Parameters.AddWithValue("@porte", Animais.Porte);

                cn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Dados inseridos com sucesso");
            }
            catch (Exception)
            {

                throw;
            }

            
        }



    }  
}
